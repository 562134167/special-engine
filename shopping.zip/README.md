## 环境说明

- NodeJS v7.10.0
- NPM v4.6.1
- Vue v2.3.3 
- vue-cli v2.8.2


## 安装依赖包

``` bash
npm i

```

``` JQ
npm install jquery --save -dev

```


## 运行本示例

```
npm run dev
```
