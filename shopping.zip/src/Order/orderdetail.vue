<template>
	<div class="orderdetail">
		<div class="list mt20">
			<div class="list_head">
				<span class="lf ml20">下单时间：</span>
				<span class="mr60 lf">{{ detaildata.time }}</span>
				<span class="lf">订单号：</span>
				<span class="mr60 lf">{{ detaildata.ordernum }}</span>
				<span class="lf">订单状态：</span>
				<span v-if="detaildata.type==1" class="mr20 lf">待收货</span>
				<div v-if="detaildata.type==1" class="btn lf mt8" @click="$emit('select', detaildata)">确认收货</div>
				<span v-if="detaildata.type==2" class="mr20 lf">待评价</span>
				<div v-if="detaildata.type==2" class="btn lf mt8"">
					<router-link :to="{ name: 'Evaluate',params:{order:detaildata,userId:userId}}" tag="li">去评价</router-link>
				</div>
				<span v-if="detaildata.type==3" class="mr20 lf">已完成</span>
			</div>
			<div class="clear list_content ml100 mt35 mb40">
				<div class=" imgmiddle lf">
					<div>
						<img src="../assets/images/ic_pay.png"/>
						<li class="mt10">订单支付</li>
						<li class="mt6 f12	color">{{ detaildata.paidtime }}</li>
					</div>
				</div>
				<div class="mt16 lf"><img src="../assets/images/line_process.png"/></div>
				<div class=" imgmiddle lf">
					<div>
						<img src="../assets/images/ic_ship.png"/>
						<li class="mt10">商品发货</li>
						<li class="mt6 f12	color">{{ detaildata.paidtime }}</li>
					</div>
				</div>
				<div class="mt16 lf"><img src="../assets/images/line_process.png"/></div>
				<div class=" imgmiddle lf">
					<div>
						<img src="../assets/images/ic_sign.png"/>
						<li class="mt10">确认签收</li>
						<li class="mt6 f12	color">{{ detaildata.paidtime }}</li>
					</div>
				</div>
			</div>	
		</div>
		<div class="list mt20">
			<div class="list_head">
				<span class="ml20">收货信息</span>
			</div>
			<div class="clear list_content ml20 mt20 mb20 clear">
				<div class="lf">
					<div class=""><span class="color">收货人：</span>{{ detaildata.ordernum }}</div>
					<div class="mt20"><span class="color">手机：</span>{{ detaildata.ordernum }}</div>
					<div class="mt20"><span class="color">地址：</span>{{ detaildata.addr }}</div>
				</div>
				<div class="lf ml100">
					<div class=""><span class="color">快递类型：</span>{{ detaildata.ordernum }}</div>
					<div class="mt20"><span class="color">运单号：</span>{{ detaildata.ordernum }}</div>
					<div class="mt20"><span class="color">物流信息：</span>{{ detaildata.ordernum }}</div>
				</div>
				<div class="lf ml120">
					<div class=""><span class="color">商品总额：</span>{{ detaildata.ordernum }}</div>
					<div class="mt15"><span class="color">运费：</span>{{ detaildata.ordernum }}</div>
					<div class="mt15"><span class="color">应付总额：</span>{{ detaildata.ordernum }}</div>
					<div class="mt15"><span class="color">付款方式：</span>{{ detaildata.ordernum }}</div>
					<div class="mt15"><span class="color">付款时间：</span>{{ detaildata.paidtime }}</div>
				</div>
			</div>	
		</div>
		<div class="list mt20">
			<div class="list_head">
				<span class="lf ml105">商品信息</span>
				<span class="ml200 lf">单价</span>
				<span class="lf ml120">数量</span>
				<span class="ml120 lf">订单金额</span>
				<span class="lf ml120">状态</span>
			</div>
			<div class="clear list_content mt24 ml30 mb30">
				<div class="img lf">
					<img width="100%" :src="detaildata.imgsrc"/>
				</div>
				<div class="ml10 lf ">
					<div class="name">{{ detaildata.name }}</div>
					<div class="color">{{ detaildata.color }} {{ detaildata.color }}</div>
				</div>
				
				<div class="ml40 prise lf">
					{{ detaildata.prise }}
				</div>
				<div class="ml80 goodsnum lf">
					×{{ detaildata.goodsnum }}
				</div>
				<div class="amount ml80 lf">
					{{ detaildata.prise }}
				</div>
				<div class="state ml50 lf">
					<span v-if="detaildata.type==1" >等待签收</span>
					<span v-if="detaildata.type==2" >待评价</span>
					<span v-if="detaildata.type==3" >已完成</span>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import "./orderdetail.less"
	
	
	export default {
    	data () {
            return {
                page_data: [],
            }
        },
        props: ['detaildata','userId'],
        created() {
        
        },
        methods: {
            inputFunc(){
            	
            }
        },
    }
</script>

<style>
</style>