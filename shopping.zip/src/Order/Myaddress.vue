<template>
	<div class="myaddress">
		<div class="title">
			我的地址
		</div>
	</div>
</template>

<script type="text/ecmascript-6">
	import "./myaddress.less"
	export default {
		data () {
            return {
                page_data: undefined,
            }
        },
    	props: ['myaddress']
    }
</script>