<template>
	<div class="orderlist">
		<div class="title">
			我的订单
		</div>
		<div class="menu mt10 ml30">
			<ul>
				<li class="menulist1 select" @click="Intlist (1)">待收货</li>
				<li class="menulist2" @click="Intlist (2)">待评价</li>
				<li class="menulist3" @click="Intlist (3)">已完成</li>
			</ul>
		</div>
		<div class="mt20 list" v-for="order in page_data">
			<div class="list_head">
				下单时间：<span class="mr80">{{ order.time }}
				</span>订单号：<span>{{ order.ordernum }}</span>
			</div>
			<div class="clear list_content">
				<div class="img">
					<img width="100%" :src="order.imgsrc"/>
				</div>
				<div class="ml20 ">
					<div class="name">{{ order.name }}</div>
					<div class="color">{{ order.color }}</div>
				</div>
				<div class="ml50 goodsnum">
					×{{ order.goodsnum}}
				</div>
				<div class="ml85 prise">
					{{ order.prise}}
				</div>
				<div style="color: #F06565;" v-if="order.type==1" class="ml85 type">
					等待签收
				</div>
				<div style="color: #F06565;" v-if="order.type==2" class="ml85 type">
					等待评价
				</div>
				<div style="color: #31383A;" v-if="order.type==3" class="ml85 type">
					已完成
				</div>
				<div v-if="order.type==1" class="ml100">
					<div class="btn" @click="$emit('select', order)">确认收货</div>
					<div class="detail" @click="$emit('detail', order)">
						订单详情
					</div>
				</div>
				<div v-if="order.type==2" class="ml100">
					<div class="btn"><router-link :to="{ name: 'Evaluate',params:{order:order,userId:userId}}" tag="li">去评价</router-link></div>
					<div class="detail" @click="$emit('detail', order)">
						订单详情
					</div>
				</div>
				<div v-if="order.type==3" class="detail ml125" @click="$emit('detail', order)">
					订单详情
				</div>
				
			</div>
		</div>
	</div>
</template>

<script type="text/ecmascript-6">
	import "./orderlist.less"
	import $ from 'jquery'
	export default {
		data () {
            return {
                page_data: [],
                listtype:1,
            }
        },
        props: ['userId','orderlistdata'],
        created() {
        	this.userId;
            this.page_data = this.orderlistdata;

        },
        methods: {
            Intlist (type) {
                this.listtype = type;
                this.userId;
                $(".menulist"+type).addClass('select').siblings().removeClass('select');
                //this.page_data = [];      //切换订单列表数据
            },
            
        },
    	
    }
</script>