<template>
	<div class="myorder">
		
		<div class="section clear pt20">
			<ordertabs :ordertabs="page_data" @select="preview($event)"></ordertabs>
			<div class="ordercontent mb30">
				<orderlist :orderlistdata="orderlistdata" :userId="$route.params.userId" v-if="page_data.ordertype==1" @select="open($event)" @detail="loaddetail($event)"></orderlist>
				<myaddress :userId="$route.params.userId" v-if="page_data.ordertype==2"></myaddress>
				<securit :userId="$route.params.userId" v-if="page_data.ordertype==3"></securit>
				<orderdetail :detaildata="detaildata" :userId="$route.params.userId" v-if="page_data.ordertype==4"  @select="open($event)"></orderdetail>
			</div>
		</div>
		<div id="shadeDiv" v-if="shadetype">
			<div class="shadelog">
				<div class="content">请确定是否确认收货</div>
				<div class="btndiv clear">
					<div class="cancel" @click="close">取消</div>
					<div class="sure ml30" @click="sure">确定</div>
				</div>
			</div>
		</div>
	</div>
	
</template>
<style>
	.ordercontent{float: right;width: 980px;min-height: 840px;background: #FFFFFF;border-radius: 4px ;}
	.ordercontent>div>.title{height:40px; font-size:24px;font-family:Arial-BoldMT;color:rgba(49,56,58,1);line-height:40px;padding-top: 30px;padding-left: 30px;}
	.shadelog{width: 324px;height: 181px;background: #FFFFFF;border-radius: 4px ;margin: 200px auto;opacity: 1;}
	.shadelog>.content{font-size:18px;font-family:PingFangSC-Regular;color:rgba(49,56,58,1);height: 109px;line-height: 109px;text-align: center;}
	.shadelog>.btndiv{width: 214px;margin: 0 auto;}
	.shadelog>.btndiv>div{width:90px;height:32px; border-radius: 2px ;font-size:14px;font-family:PingFangSC-Regular;color:rgba(49,56,58,1);line-height: 32px;float: left;opacity: 0.9;text-align: center;cursor: pointer;}
	.shadelog>.btndiv>div:hover{opacity: 1;}
	.shadelog>.btndiv>.cancel{border: 1px solid #D8D8D8 ;}
	.shadelog>.btndiv>.sure{border: 1px solid #FFD800;background: #FFD800;}
</style>
<script type="text/ecmascript-6">
    import ordertabs from "./ordertabs.vue"
    import orderlist from "./orderlist.vue"
    import myaddress from "../addr/myaddress.vue"
    import securit from "./securit.vue"
    import orderdetail from "./orderdetail.vue"
    import $ from 'jquery'
    
    export default{
    	 data () {
            return {
                page_data: [],     //用户信息,用于左边菜单
	            shadetype:false,      //收货弹窗开关
	            redata:[],            //确认收货信息
	            detaildata:[],        //订单详情数据
	            orderlistdata:[],       //订单列表数据
	            }
	    },
        created() {

            this.page_data = {
            	"img_src":this.$route.params.img_src,
            	"name":this.$route.params.name,
            	"ordertype":1,    //左边菜单切换控制
            };
            this.orderlistdata = [{     //订单列表数据
	            	"id":1001,
	            	"name":"猫脸大头抱枕2017blablabl...111111ss1",
	            	"time":"2017-12-1",  
	            	"ordernum":232312243212,
	            	"type":1,  
	            	"imgsrc":1,  
	            	"goodsnum":2,  
	            	"color":"黑色",  
	            	"prise":"￥ 20.00", 
	            	"paidtime":"2017-11-27 18:22:30",
	            	"addr":"广东省深圳市福田区郑华路设计大厦1815",
	            },
	            {
	            	"id":1001,
	            	"name":"1猫脸大头抱枕2017",
	            	"time":"2017-12-4",  
	            	"ordernum":232312243212,
	            	"type":2,  
	            	"imgsrc":1,  
	            	"goodsnum":1,  
	            	"color":"黑色",  
	            	"prise":"￥ 40.00",  
	            	"paidtime":"2017-11-27 18:22:30",
	            	"addr":"广东省深圳市福田区郑华路设计大厦1815",
	            }
	        ];
            if(this.$route.params.page_data.ordertype){
            	this.page_data.ordertype = this.$route.params.page_data.ordertype;
            }
			
        },
        methods: {
            preview (type) {
                this.page_data.ordertype = type;
            },
            open(data){
            	this.shadetype=true;
            	this.redata = data;
            },
            close(){
            	this.shadetype=false;
            	this.redata = [];
            },
            sure(){
            	//this.redata                //上传收货确认信息
            	this.shadetype=false;
            	
            	this.detaildata.type = 2;
            	console.log(this.detaildata);
            },
            loaddetail(data){
            	this.page_data.ordertype = 4;
            	if(data){
            		this.detaildata = data;
            	}
            },
            
        },
        mounted(){
            document.title = "我的订单"
        },
    	
        components: {ordertabs,orderlist,myaddress,securit,orderdetail},
    }
</script>

