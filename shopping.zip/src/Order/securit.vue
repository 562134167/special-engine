<template>
	<div class="securit" v-if="!setword">
		<div class="title">
			安全设置
		</div>
		<div class="mt30 ml30 clear">
			<img v-if="!page_data.password" class="lf" src="../assets/images/ic_attention.png"/>
			<img v-if="page_data.password" class="lf" src="../assets/images/ic_safe.png"/>
			<span class="ml5 lf">支付密码</span>
			<span class="ml60 op07 lf">支付密码用于商城订单支付</span>
			<span v-if="!page_data.password" class="rf mr130 btn" @click="set(1)">创建支付密码</span>
			<span v-if="page_data.password" class="rf mr130 btn" @click="set(2)">修改支付密码</span>
		</div>
	</div>
	<div class="set" v-else>
		<div class="title">
			{{ settitle }}
		</div>
		<div class="rows clear mt30">
			<div class="title">
				手机号
			</div>
			<div class="lf f24">
				{{ page_data.newtel }}
			</div>
		</div>
		<div class="rows clear mt20">
			<div class="title">
				验证码
			</div>
			<input @input="inP" v-model="page_data.Code" type="" name="" id="" value="" />
			<div class="sentbtn lf ml10" :class="{senting:timeplay==true}" @click="inv">
				<span v-if="!timeplay">发送</span>
				<span v-else>{{ time }}</span>
			</div>
		</div>
		<div class="rows clear mt20">
			<div class="title">
				新支付密码
			</div>
			<input @input="inP" maxlength="6" v-model="page_data.newpassword" type="password" class="word" name="" id="" value="" />
		</div>
		<div class="rows clear mt20">
			<div class="title">
				确认密码
			</div>
			<input @input="inP" maxlength="6" v-model="page_data.Confirm" type="password" class="word" name="" id="" value="" />
		</div>
		<div class="msg mt2">{{ msg }}</div>
		<div class="rows clear mt2">
			<div @click="sub" class="subbtn lf ml120" :class="{ready:subready}">
				提交
			</div>
		</div>
		<div id="shadeDiv" v-if="shadetype">
			<div class=" pt30 shadelog ">
				<div class=" img"><img class="mt16 ml17" src="../assets/images/gou.png" alt="" /></div>
				<div class="mt10 tc">设置完成</div>	
			</div>
		</div>
	</div>
</template>

<script>
	import "./securit.less"
	export default {
		data () {
            return {
                page_data: {},
                setword:false,
                settitle:'',
                time:59,
	            timeplay:false,
	            subready:false,
	            msg:' ',
	            shadetype:false,
            }
        },
    	props: ['userId'],
    	created() {
    		this.page_data.password = true;
    		this.page_data.tel="13712345678";
    		var tel = this.page_data.tel;
    		var mytel = tel.substr(3, 4);  
            this.page_data.newtel=this.page_data.tel.replace(mytel, "****");
    	},
    	 methods: {
    	 	set(type){
    	 		if(type==1){
    	 			this.settitle ="创建支付密码";
    	 		}
    	 		if(type==2){
    	 			this.settitle ="修改支付密码";
    	 		}
    	 		this.setword=true;
    	 	},
    	 	//定时器
		    inv: function () {
		    	if(!this.timeplay){
		    		this.timeplay = true;
		        	var timer = setInterval(() => {
		          	this.time-=1;
		          	console.log(this.time)
		          	if(this.time==0){
		          		clearInterval(timer);
		          		this.time = 59;
		          		this.timeplay = false;
		          	}	
		          	//此时的this指向是该vue组件，不管在哪个地方使用，指向都是该vue组件。
		       		}, 1000)
		        } 	
		    },
		    inP(){
		    	if(this.page_data.Code&&this.page_data.newpassword&&this.page_data.Confirm){
		    		this.subready =true;
		    	}
		    	else{
		    		this.subready =false;
		    	}
		    },
		    sub(){
		    	if(this.subready){
			    	if(this.page_data.newpassword!=this.page_data.Confirm){
			    		this.msg="两次密码输入不一致！";
			    		return;
			    	}
			    	else{
			    		this.msg=" ";
			    		this.shadetype=true;
		            	setTimeout((	) => {
				          	this.shadetype=false;
				          	this.setword=false;
				       	}, 1000);
			    	}
		    	}
		    }
    	 },
    }
</script>