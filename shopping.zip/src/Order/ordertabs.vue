<template>
	<div class="ordertabs">
        <div class="user">
        	<div class="headimg"><img width="100%" :src="ordertabs.img_src"/></div>
        	<li>{{ ordertabs.name }}</li>
        </div>
        <ul class="tab_item">
        	<li @click="$emit('select', 1)" :class="{select:ordertabs.ordertype == 1}">我的订单</li>
        	<li @click="$emit('select', 2)" :class="{select:ordertabs.ordertype == 2}">我的地址</li>
        	<li @click="$emit('select', 3)" :class="{select:ordertabs.ordertype == 3}" >安全设置</li>
        </ul>
    </div>
</template>

<script type="text/ecmascript-6">
	import "./ordertabs.less"
	export default {
		data () {
            return {
                page_data: undefined,
            }
        },
    	props: ['ordertabs'],
    }
</script>
