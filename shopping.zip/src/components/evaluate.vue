<template>
	<div class="evaluate">
		<div class="title">评价订单</div>
		<div class="f14 mt10 tc op07">
			订单编号：<span class="mr60">{{ page_data.ordernum }}</span>{{ page_data.time }}
		</div>
		<div class="content clear">
			<div class="goods lf">
				<div class="img"><img width="180px" :src="page_data.imgsrc"/></div>
				<div class="mt20 op09 tc">{{ page_data.name }}</div>
				<div class="mt10 tc">{{ page_data.prise }}</div>
				<div class="mt10 op07 tc">{{ page_data.color }}</div>
			</div>
			<div class="lf ml100">
				<div class="op09">商品满意度</div>
				<div class="clear mt10">
					<em class="em1 select" @click="changescore(1)"></em>
					<em class="em2 select" @click="changescore(2)"></em>
					<em class="em3 select" @click="changescore(3)"></em>
					<em class="em4 " @click="changescore(4)"></em>
					<em class="em5 " @click="changescore(5)"></em>
					<span class="f18 ml15">{{ score }}分</span>
				</div>
				<div class="op09 mt30">商品满意度</div>
				<div class="commenttext mt10">
					<textarea @input ="inputFunc" v-model="commenttext" maxlength="300" name="" rows="" cols="" placeholder="商品怎么样，给过评价吧"></textarea>
					<div class="limited">{{ textlegth }}/300</div>
				</div>
			</div>
		</div>
		<div class="subdiv">
			<div class="clear pt40">
				<div @click="sub" class="btn lf">提交评价</div>
				<div class="mt48 ml20 lf op09 f14">
					<input class="mr2" type="checkbox" v-model="anonymous" value="true"/>
					匿名评价
				</div>
			</div>
		</div>
		<div id="shadeDiv" v-if="shadetype">
			<div class=" pt30 shadelog ">
				<div class=" img"><img class="mt16 ml17" src="../assets/images/gou.png" alt="" /></div>
				<div class="mt10 tc">评价完成</div>	
			</div>
		</div>
	</div>
</template>

<script>
	import "./evaluate.less"
	import $ from 'jquery'
	
	export default {
    	data () {
            return {
                page_data: [],
                score:3,
                commenttext:"",
                textlegth:0,
                anonymous:false,
                shadetype:false,
            }
        },
        created() {
        	this.page_data = this.$route.params.order;
        },
        mounted(){
            document.title = "评价订单"
        },
        methods: {
        	changescore(num){
            	this.score=num;
            	$("em").removeClass('select');
            	for(var i =1;i<=num;i++){
            		$(".em"+i).addClass('select');
            	}
            },
            inputFunc(){
            	this.textlegth = this.commenttext.length;
            },
            sub(){
            	var subdata={};      //上传评价信息
            	subdata.anonymous = this.anonymous;
            	subdata.score = this.score;
            	subdata.commenttext = this.commenttext;
            	subdata.ordernum = this.page_data.ordernum;
            	
            	this.shadetype=true;
            	setTimeout((	) => {
		          	this.shadetype=false;
		          	var userId = this.$route.params.userId;
		          	this.$router.push({ name: 'MyOrder', params: { userId: userId }})
		       	}, 1000);
		       	
		       	
            },
        },
    }
</script>