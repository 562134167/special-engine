<template>
	<div class="footer">
		<div class="section">
			<div class="title pt25">
				商城
			</div>
			<div class="text mt8">Copyright © 2017  深圳市科技有限公司 粤ICP备1721238号</div>
			<div class="text mt5">联系地址：深圳市福田区振华路设计大厦 <span class="ml20">联系电话：12345678901</span></div>
		</div>
	</div>
</template>

<script type="text/ecmascript-6">
    import "./footer.less"
    export default {}
    
</script>