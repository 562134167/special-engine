<template>
    <div class="tabs clear">
        <ul>
            <router-link :to="{ name: 'Home',params:{userId:tabs.userId}}" tag="li" class="lf">
                	商城	
            </router-link>
            <router-link :to="{ name: 'Home',params:{userId:tabs.userId}}" tag="li" class="rf ml40">
                <img src="../assets/images/logo.png"/>
            </router-link>
            <router-link :to="{ name: '' }" tag="li" class="rf ml40 mr80 Headportrait" v-if="tabs.img_src">
            	<img width="100%" :src="tabs.img_src"/>
            </router-link>
            <div v-else>
            	<router-link :to="{ name: '' }" tag="li" class="rf ml8" >
            		注册
	            </router-link>
	            <li class="rf ml8 line" >
	            </li>
	            <router-link :to="{ name: ''}" tag="li" class="rf ml40">
	            	登陆
	            </router-link>
            </div>
            
            <router-link :to="{ name: 'MyOrder',params:{userId:tabs.userId,img_src:tabs.img_src,name:tabs.name}}" tag="li" class="rf">
            	我的订单
            </router-link>
        </ul>
    </div>
</template>
<script>
    import "./tabs.less"
    //const _data = require("../assets/images/category.svg").toString()
    //console.log(_data)
    export default {
    	props: ['tabs']
    }
</script>
