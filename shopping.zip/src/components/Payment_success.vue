<template>
<div class="bg pt20">
	<div class="Payment_success">
		<div class="pt60">
			<img src="../assets/images/ic_uploadedsuccessfully.png"/>
			订单支付成功，我们将尽快为您发货
		</div>
		<div class="mt20">
			您可以返回商城首页
			<span @click="home" class="ml10 blue">商城</span>
		</div>
		<div class="mt10">
			还可以查看我的订单
			<span @click="myorder" class="ml10 blue">我的订单</span>
		</div>
	</div>
</div>
</template>

<style>
	.bg{background: rgba(240,240,240,1); min-height: 600px;}
	.Payment_success{width:1200px;height:288px; background:rgba(255,255,255,1);border-radius: 4px ;margin: 0 auto; }
	.Payment_success>div{text-align: center;height: 48px;line-height: 48px;}
	.blue{color: #5B9BAD; cursor: pointer;}
</style>

<script>
	export default{
		methods: {
    		home(){
            	this.$router.push({ name:'Home'});
            },
            myorder(){
            	this.$router.push({ name:'MyOrder'});
            },
       }
	}
</script>