<template>
    <div v-if="page_data">
        <div class="">
            <slider :slides="page_data.slider"></slider>
        </div>
         <div class="section">
            <good-list :goods="page_data.HotList" :userId="$route.params.userId"
                       heading="热门商品" pagesize="4">
            </good-list>
        </div>
        <div class="section">
            <good-list :goods="page_data.BrandList" :userId="$route.params.userId"
                       heading="品牌精选" pagesize="99">
            </good-list>
        </div>
 
        
    </div>
</template>
<script type="text/ecmascript-6">
    import Slider from "./components/slider.vue"
    import GoodList from "./goods/list.vue"
    import faker from "./fixtures/faker.js"

    export default{
        data () {
            return {
                page_data: undefined,
                selected:undefined
            }
        },
        components: {Slider, GoodList},
        created() {

            this.page_data = {
            	"slider":[],
            	"HotList":[],
            	"BrandList":[]
            };
            this.page_data.slider=faker.getHomeData().top;     //轮播
            this.page_data.HotList=faker.getHomeData().promotions;    //热门商品
            this.page_data.BrandList=faker.getHomeData().promotions;  //品牌精选
//            this.$http.get('/gooks/promotions', (res)=> {
//                this.page_data = res.data
//            }, (error)=> {
//                // 处理出错信息
//            })

        },
        mounted(){
            document.title = "商城"
        },
        
    }
</script>