<template>
	<div class="myaddress">
		<div class="title">
			我的地址
		</div>
		<div class="menu">
			<span class="op09 mr20" @click="NewAddress"><img align="middle" src="../assets/images/ic_add.png"/>新增地址</span>
			已创建 {{ page_data.length }} 个，还可创建 {{ maxlength-page_data.length }} 个地址
		</div>
		<div class="ml20 mt10 content">
			<table width="940px" border="0" cellspacing="0" cellpadding="0">
				<colgroup>
					<col width="150px" />
					<col width="340px" />
					<col width="200px" />
					<col width="50px" />
					<col width="200px" />
				</colgroup>
				<tr>
					<th>收件人</th>
					<th>地址</th>
					<th>联系方式</th>
					<th>操作</th>
					<th> </th>
				</tr>
				<tr v-for="addr in page_data">
					<td >{{ addr.name }}</td>
					<td >{{ addr.CityName }}{{ addr.DisName }}{{ addr.addrdetail }}</td>
					<td >{{ addr.tel }}</td>
					<td class="bluecolor" @click="ChangeAddress(addr)">编辑</td>
					<td v-if="addr.default"><div class="">默认地址</div></td>
					<td class="bluecolor" v-if="!addr.default" @click="Setdefault(addr)">设为默认地址</td>
				</tr>
			</table>
		</div>
		<div class="shadeDiv" v-if="shadetype">
			<div class="shadelog">
				<div class="title">{{ logtitle }}</div>
				<div class="mt20 clear">
					<div class="title lf">收件人</div>
					<input class="lf ml15" v-model="logdata.name" type="" name="" id="" value="" />
					<div class="title lf ml30">手机号</div>
					<input class="lf ml15" v-model="logdata.tel" type="" name="" id="" value="" />
				</div>
				<div class="mt10 clear">
					<div class="title lf">所在地区</div>
					<select value="请选择" @change="province" class="ml15" name="" v-model="logdata.ProID">
						<option value="-1">请选择</option>
						<option   v-for="province in addrdata.provinceList" :value="province.ProID">{{ province.ProName }}</option>
					</select>
					<select @change="city" class=""  name="" v-model="logdata.CityID">
						<option value="-1">请选择</option>
						<option v-for="city in addrdata.cityList" v-if="city.ProID==ProID" :value="city.CityID"> {{ city.CityName }} </option>
					</select>
					<select class=""  name="" v-model="logdata.Id">
						<option value="-1">请选择</option>
						<option v-for="county in addrdata.countyList" v-if="county.CityID==CityID" :value="county.Id"> {{ county.DisName }} </option>
					</select>
				</div>
				<div class="mt20 clear">
					<div class="title lf">详细地址</div>
					<textarea class="lf ml15" v-model="logdata.addrdetail" id="" placeholder="详细地址，街道，门牌号等" ></textarea>
				</div>
				<div class="btndemo mt20 clear">
					<div class="lf">
						<input @change="checkbox($event)"  type="checkbox" :checked="logdata.default" />设为默认
					</div>
					<div class="cancel ml15 rf" @click="close()">取消</div>
					<div class="sure  rf" @click="sure">确定</div>
					
				</div>
			</div>
		</div>
	</div>
</template>

<script type="text/ecmascript-6">
	import "./myaddress.less"
	import "./area.less"
	import data from './area.json'
	export default {
		data () {
            return {
                page_data: [],  //地址列表数据
                maxlength:3,
                logtitle:"",
                shadetype:false,
                logdata:[],     //新增修改地址数据
                addrdata:[],
                ProID:'',
                CityID:'',
                default:false,
            }
        },
    	props: ['userId'],
    	created() {
    	 	this.page_data=[
    	 		{name:"小静静",ProName:"广东省",CityName:"深圳市",DisName:"福田区",addrdetail:"郑华路设计大厦",tel:"18381687365",default:true},
    	 		{name:"小静静",ProName:"广东省",CityName:"深圳市",DisName:"福田区",addrdetail:"郑华路设计大厦",tel:"18381687365",default:false}
    	 	];
    	 	this.addrdata = data;
    	 	this.logdata.ProID = -1;
    	 	this.logdata.CityID = -1;
    	 	this.logdata.Id = -1;
    	 	
    	 },
    	 methods: {
    	 	Setdefault(data){
            	this.logdata = data;
            	this.logdata.default = true;
            	
//            	this.$http.get('/user', {
//					params: {
//					ID: 12345
//					}
//				})
//				.then(function (response) {
//					this.page_data=response;
//				})
//				.catch(function (error) {
//					console.log(error);
//				});
				this.logdata =[];

           },
    	 	NewAddress(){
            	this.shadetype=true;
            	this.logtitle = "新建地址";
            },
            ChangeAddress(data){
            	var newdata = data;
            	this.shadetype=true;
            	this.logtitle = "修改地址";
            	this.logdata = newdata;
            	for(var i=0;i<this.addrdata.provinceList.length;i++){
            		if(this.logdata.ProName == this.addrdata.provinceList[i].ProName){
            			this.logdata.ProID = this.addrdata.provinceList[i].ProID;
            		}
            	}
            	this.ProID = this.logdata.ProID;
            	
            	for(var i=0;i<this.addrdata.cityList.length;i++){
            		if(this.logdata.CityName == this.addrdata.cityList[i].CityName){
            			this.logdata.CityID = this.addrdata.cityList[i].CityID;
            		}
            	}
            	this.CityID = this.logdata.CityID;
            	for(var i=0;i<this.addrdata.countyList.length;i++){
            		if(this.logdata.DisName == this.addrdata.countyList[i].DisName){
            			this.logdata.Id = this.addrdata.countyList[i].Id;
            		}
            	}
            },
            province(){
            	this.ProID = this.logdata.ProID;
            	this.logdata.CityID = -1;
    	 		this.logdata.Id = -1;
            },
            city(){
            	this.CityID = this.logdata.CityID;
            	this.logdata.Id = -1;
            },
            close(){
            	this.shadetype=false;
            	this.logdata = [];
            	this.logdata.ProID = -1;
	    	 	this.logdata.CityID = -1;
	    	 	this.logdata.Id = -1;
	    	 	this.page_data=[
    	 		{name:"小静静",ProName:"广东省",CityName:"深圳市",DisName:"福田区",addrdetail:"郑华路设计大厦",tel:"18381687365",default:true},
    	 		{name:"小静静",ProName:"广东省",CityName:"深圳市",DisName:"福田区",addrdetail:"郑华路设计大厦",tel:"18381687365",default:false}
    	 	];
	    	 	
            },
            sure(){
            	//this.logdata                //上传收货确认信息
            	this.logdata.default = this.default;
            	this.shadetype=false;
            	
            	this.logdata = [];
            	this.logdata.ProID = -1;
	    	 	this.logdata.CityID = -1;
	    	 	this.logdata.Id = -1;
            	
            },
            checkbox(el){
            	this.default = el.currentTarget.checked;
            },
            
            
    	 },
    	 mounted(){
		  　　
		}
    }
</script>