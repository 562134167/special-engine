<template>
	<div class="payment pt20">
		<div class="content">
			<div class="list">
				<div class="title">收货信息</div>
				<div class="clear">
					<div class="lf ml20 mt15 mb30">
						<div class="clear">
							<img class="lf" src="../assets/images/ic_defaultaddress.png"/>
							<span class="lf ml10">默认地址</span>
							<div class="lf btn ml20" @click="ChangeAddress(addrdefdata)">修改</div>
						</div>
						<div><span class="title">收货人：</span>{{ addrdefdata.name }}</div>
						<div><span class="title">手机：</span>{{ addrdefdata.tel }}</div>
						<div><span class="title">地址：</span>{{ addrdefdata.ProName }}{{ addrdefdata.CityName }}{{ addrdefdata.DisName }}{{ addrdefdata.addrdetail }}</div>
					</div>
					<div class="rf mr100 mt55 btndiv">
						<div class="tc color mt10 ml80">切换地址</div>
						<div @click="NewAddress()" class="btn">新建地址</div>
					</div>
				</div>
			</div>
			<div class="list mt20">
				<div class="title">
					<span>商品信息</span>
					<span class="ml356">单价</span>
					<span class="ml140">数量</span>
					<span class="ml140">服务信息</span>
					<span class="ml140">订单金额</span>
				</div>
				<div class="clear list_content">
					<div class="img">
						<img width="100%" :src="goodsdata.img_url"/>
					</div>
					<div class="type">
						<div class="name">{{ goodsdata.title }}</div>
						<div class="color">{{ goodsdata.color }} <span class="ml10">{{ goodsdata.type }}</span></div>
					</div>
					<div class="ml70 prise">
						{{ goodsdata.prise }}
					</div>
					<div class="ml120 goodsnum">
						×{{ goodsdata.num }}
					</div>
					<div class="ml120 infma">
						3-5天抵达
					</div>
					<div class="ml100 amount">
						{{ goodsdata.prise }}
					</div>
					
				</div>
			</div>
			<div class="list mt20">
				<div class="title">结算信息</div>
				<div class="clear">
					<div class="rf mr100 pay_content">
						<div class="clear mt30">
							<div class=" rf">
								{{paydata.prise}}
							</div>
							<div class=" rf">商品合计：</div>
						</div>
						<div class="clear mt10">
							<div class=" rf">
								{{paydata.prise}}
							</div>
							<div class=" rf">运费：</div>
						</div>
						<div class="clear mt20">
							<div class="line rf"></div>
						</div>
						<div class="clear mt20">
							<div class="f24 red rf">
								{{paydata.prise}}
							</div>
							<div class="rf">应付魔币：</div>
						</div>
						<div class="btn mt20" @click="pay_log()">去付款</div>
						<div class="clear mt20">
							<div class="rf">
								{{paydata.tel}}
							</div>
							<div class="rf mr20">
								{{paydata.name}}
							</div>
						</div>
						<div class="addr mt10">
							{{ addrdefdata.ProName }}{{ addrdefdata.CityName }}{{ addrdefdata.DisName }}{{ addrdefdata.addrdetail }}
						</div>
						
					</div>
				</div>
			</div>
		</div>
		<div class="shadeDiv" v-if="shadetype">
			<div class="shadelog">
				<div class="title">{{ logtitle }}</div>
				<div class="mt20 clear">
					<div class="title lf">收件人</div>
					<input class="lf ml15" v-model="logdata.name" type="" name="" id="" value="" />
					<div class="title lf ml30">手机号</div>
					<input class="lf ml15" v-model="logdata.tel" type="" name="" id="" value="" />
				</div>
				<div class="mt10 clear">
					<div class="title lf">所在地区</div>
					<select value="请选择" @change="province" class="ml15" name="" v-model="logdata.ProID">
						<option value="-1">请选择</option>
						<option   v-for="province in addrdata.provinceList" :value="province.ProID">{{ province.ProName }}</option>
					</select>
					<select @change="city" class=""  name="" v-model="logdata.CityID">
						<option value="-1">请选择</option>
						<option v-for="city in addrdata.cityList" v-if="city.ProID==ProID" :value="city.CityID"> {{ city.CityName }} </option>
					</select>
					<select class=""  name="" v-model="logdata.Id">
						<option value="-1">请选择</option>
						<option v-for="county in addrdata.countyList" v-if="county.CityID==CityID" :value="county.Id"> {{ county.DisName }} </option>
					</select>
				</div>
				<div class="mt20 clear">
					<div class="title lf">详细地址</div>
					<textarea class="lf ml15" v-model="logdata.addrdetail" id="" placeholder="详细地址，街道，门牌号等" ></textarea>
				</div>
				<div class="btndemo mt20 clear">
					<div class="lf">
						<input @change="checkbox($event)"  type="checkbox" :checked="logdata.default" />设为默认
					</div>
					<div class="cancel ml15 rf" @click="close()">取消</div>
					<div class="sure  rf" @click="sure">确定</div>
					
				</div>
			</div>
		</div>
		<div class="shadeDiv" v-if="paylog">
			<div class="paylog">
				<div class="f24">确认支付</div>
				<div class="mt20">
					<span class="op09">支付金额：</span>
					<span class="red f18">{{paydata.prise}}</span>
				</div>
				<div class="mt20">
					<span class="op09">收款方：</span>
					<span class="f18">筑亿科技</span>
				</div>
				<div class="mt20 op09">
					输入支付密码：
				</div>
				<div class="mt20"><input maxlength="6" v-model="paydata.password" type="password" name="" id="" value="" /></div>
				<div class="mt10 op09 changepassword" @click="changepassword">
					忘记支付密码
				</div>
				<div class="paybtn mt20" @click="pay_sub">立即支付</div>
			</div>
		</div>
	</div>
</template>

<script  type="text/ecmascript-6">
	import "./Payment.less"
	import "../addr/area.less"
	import data from '../addr/area.json'
	export default{
    	data (){
    		return {
    			paydata:[],
    			goodsdata:[],
    			userId:'',
    			addrdata:'',
    			logtitle:"",
                shadetype:false,
                logdata:[],     //新增修改地址数据
                addrdefdata:[],
                ProID:'',
                CityID:'',
                default:false,
                paylog:false,
    		}
    	},
    	created() {
    		this.userId = this.$route.params.userId;
    		this.addrdefdata=
    	 		{name:"小静静",ProName:"广东省",CityName:"深圳市",DisName:"福田区",addrdetail:"郑华路设计大厦",tel:"18381687365",default:true}
    	 	;
    	 	this.goodsdata = this.$route.params.goodsdata;
    	 	for (var p in this.goodsdata) {
           		this.paydata[p]=this.goodsdata[p];
			}
			for (var arg in this.addrdefdata) {
           		this.paydata[arg]=this.addrdefdata[arg];
			}
    	 	console.log(this.paydata);
    	 	this.addrdata = data;
    	 	this.logdata.ProID = -1;
    	 	this.logdata.CityID = -1;
    	 	this.logdata.Id = -1;
    		
    	},
    	methods: {
    		NewAddress(){
            	this.shadetype=true;
            	this.logtitle = "新建地址";
            },
            ChangeAddress(data){
            	var newdata = data;
            	this.shadetype=true;
            	this.logtitle = "修改地址";
            	this.logdata = newdata;
            	for(var i=0;i<this.addrdata.provinceList.length;i++){
            		if(this.logdata.ProName == this.addrdata.provinceList[i].ProName){
            			this.logdata.ProID = this.addrdata.provinceList[i].ProID;
            		}
            	}
            	this.ProID = this.logdata.ProID;
            	
            	for(var i=0;i<this.addrdata.cityList.length;i++){
            		if(this.logdata.CityName == this.addrdata.cityList[i].CityName){
            			this.logdata.CityID = this.addrdata.cityList[i].CityID;
            		}
            	}
            	this.CityID = this.logdata.CityID;
            	for(var i=0;i<this.addrdata.countyList.length;i++){
            		if(this.logdata.DisName == this.addrdata.countyList[i].DisName){
            			this.logdata.Id = this.addrdata.countyList[i].Id;
            		}
            	}
            },
            province(){
            	this.ProID = this.logdata.ProID;
            	this.logdata.CityID = -1;
    	 		this.logdata.Id = -1;
            },
            city(){
            	this.CityID = this.logdata.CityID;
            	this.logdata.Id = -1;
            },
            close(){
            	this.shadetype=false;
            	this.logdata = [];
            	this.logdata.ProID = -1;
	    	 	this.logdata.CityID = -1;
	    	 	this.logdata.Id = -1;
	    	 	
            },
            sure(){
            	//this.logdata                //上传收货确认信息
            	this.logdata.default = this.default;
            	this.shadetype=false;
            	
            	this.logdata = [];
            	this.logdata.ProID = -1;
	    	 	this.logdata.CityID = -1;
	    	 	this.logdata.Id = -1;
            	
            },
            checkbox(el){
            	this.default = el.currentTarget.checked;
            },
            pay_log(){
            	this.paylog =true;
            },
            pay_sub(){
            	this.$router.push({ name:'Payment_success'});
            },
            changepassword(){
            	this.$router.push({ name:'MyOrder', params: { page_data:{ordertype: 3},userId:this.userId }})
            }
    	},
    }
</script>

