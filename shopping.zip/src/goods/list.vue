<template>
    <div class="good-list">
        <div class="header">
            <div class="heading">{{ heading }}</div>
        </div>
        <div class="good-items clear">
            <router-link class="good" 
                 v-for="(good,index) in goods"
                 v-if="index<pagesize"
                 tag="div"
                 :to="{ name: 'Gooddetail' ,params:{goodsdata:good,userId:userId}}" 
                 >
                <div class="cover middle">
                    <img :src="good.img_url"/>
                </div>
                <div class="title">{{ good.title }}</div>
                <div class="entitle">{{ good.entitle }}</div>
                 <div class="prise">{{ good.prise }}</div>
            </router-link>
        </div>
    </div>
</template>

<script type="text/ecmascript-6">
    import "./list.less"

    export default{
        props: ['heading', 'goods','pagesize','userId'],
    }
</script>