<template>
	
	<div class="mt20  information">
		<table class="ml20 mr20" width="100%" border="0" cellspacing="0" cellpadding="0">
			<colgroup>
				 <col width="8%"></col>
				 <col width="25%"></col>
				  <col width="8%"></col>
				 <col width="25%"></col>
				  <col width="8%"></col>
				 <col width="25%"></col>
			</colgroup>
			<tr class="">
				<td>品牌名称</td>
				<td>{{ infdata.name }}</td>
				<td>证书编号</td>
				<td>{{ infdata.num }}</td>
				<td>加热方式</td>
				<td>{{ infdata.type }}</td>
			</tr>
			<tr class="">
				<td>品牌名称</td>
				<td>{{ infdata.name }}</td>
				<td>证书编号</td>
				<td>{{ infdata.num }}</td>
				<td>加热方式</td>
				<td>{{ infdata.type }}</td>
			</tr>
		</table>
		<div class="img"><img width="100%" :src="infdata.img"/></div>
	</div>

</template>
<style>
	.information td{
		height:40px; 
		font-size:14px;
		color:rgba(49,56,58,1);
		line-height:40px;
	}
	.information td:nth-child(odd){
		color:rgba(49,56,58,0.5);
	}
	.img{width: 100%;}
</style>
<script>
	export default{
    	data () {
            return {
               page_data: undefined,
            }
        },
        props: ['infdata'],
        created() {
        	console.log(this.infdata);
        }
   }
</script>

