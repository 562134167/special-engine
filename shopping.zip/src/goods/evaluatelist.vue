<template>
	<div class="mb20">
		<div class="list clear mt40 pb40" v-for="evaluate in evaluatelist">
			<div class="user lf">
				<div class="headimg"><img :src="evaluate.img"/></div>
				<div class="mt12 tc">{{ evaluate.name }}</div>
			</div>	
			<div class="lf ml30">
				<div class="clear score">
					<em :class="{select:evaluate.score>=1}"></em>
					<em :class="{select:evaluate.score>=2}"></em>
					<em :class="{select:evaluate.score>=3}"></em>
					<em :class="{select:evaluate.score>=4}"></em>
					<em :class="{select:evaluate.score==5}"></em>
				</div>
				<div class="mt10 fc87 f12">
					<span class="mr15">{{ evaluate.type }}</span>
					<span>{{ evaluate.color }}</span>
				</div>
				<div class="mt10">{{ evaluate.content }}</div>
				<div class="mt15 fc87 op07">
					{{ evaluate.time }}
				</div>
			</div>	
		</div>
	</div>
</template>

<script>
	export default{
        props: ['evaluatelist'],
   }
</script>

<style>
	.list{
		width: 933px;
		margin: 0 auto;
		border-bottom: 1px dashed rgba(151,151,151,1);
	}
	.user{width: 82px;}
	.headimg{
		height: 80px;
		width: 80px;
		background:rgba(216,216,216,1);
		border: 1px solid rgba(151,151,151,1);
		border-radius: 50%;
		overflow: hidden;
	}	
	.score{
        height: 21px;
        line-height: 21px;
    }
    .score>em{
        margin-right: 10px;
        width: 20px;
        height: 21px;
        display: block;
        float: left;
        background: url(../assets/images/ic_satisfied.png);
    }
   	.score>em.select{
        background: url(../assets/images/ic_satisfied_pre.png);
    }
</style>