<template>
    <div class="Gooddetail ">
    	<div class="clear section mt40">
    		<div class="lf bigimg">
    			<img v-for="(imgsrc,index) in goodsdata.imgsrc" :class="{fade:imgtype==index}" width="100%" :src="imgsrc"/>
    		</div>
    		<div class="lf imgmenu">
    			<img v-for="(imgsrc,index) in goodsdata.imgsrc" :class="{select:imgtype==index}" @click="changeimg(index)" width="100%" :src="imgsrc"/>
    		</div>
    		<div class="lf ml80">
    			<div class="f18">{{ goodsdata.title }}</div>
    			<div class="mt5">{{ goodsdata.entitle }}</div>
    			<div class="mt20 prisediv">
    				<div class="pt10">促销价 <span class="prise ml10 mr10">{{ goodsdata.prise }}</span>魔币</div>
    				<div class="mt10">市场价 <span class="Marketvalue ml10">￥{{ goodsdata.prise }}</span></div>
    			</div>
    			<div class="mt20">
    				<div class="op07"> 型号 </div>
    				<div class="mt10 clear listcontent">
    					<div v-for="content in styledata.typedata" @click="setstyle(content.id,content.type,1)"  :class="{select:type1==content.id}">{{ content.type }}</div>
    				</div>
    			</div>
    			<div class="mt20">
    				<div class="op07"> 颜色 </div>
    				<div class="mt10 clear listcontent">
    					<div v-for="content in styledata.colordata" @click="setstyle(content.id,content.type,2)"  :class="{select:type2==content.id}">{{ content.type }}</div>
    				</div>
    			</div>
    			<div class="mt20">
    				<div class="op07"> 数量 </div>
    				<div class="mt10 clear listcontent">
    					<input v-model="num" type="number" min="1" name="" id="" value="1" />
    				</div>
    			</div>
    			<div @click="Gotobuy" class="btn mt40">立即购买</div>
    		</div>
    	</div>
    	<div class="content mb90 mt60">
    		<div class="menu clear mt20 ml20">
    			<div :class="{select:menutype==1}" @click="changemenu(1)">产品信息</div>
    			<div :class="{select:menutype==2}" class="ml60" @click="changemenu(2)">产品评价</div>
    		</div>
    		<information class="" :infdata="infdata" v-if="menutype==1"></information>
    		<evaluatelist :evaluatelist="evaluatelist" v-if="menutype==2"></evaluatelist>
    	</div>
    </div>
</template>
<script type="text/ecmascript-6">
	import information from "./information.vue"
	import evaluatelist from "./evaluatelist.vue"
	import "./Gooddetail.less"
    
    export default{
    	data () {
            return {
            	userId:'',
                goodsdata: undefined,
                imgtype:0,
                styledata:[],
                menutype:1,
                infdata:undefined,
                evaluatelist:[],
                num:1,
                type1:'',
                type2:'',
            }
        },
        components: {information,evaluatelist},
        created() {
        	this.userId=this.$route.params.userId;
    	 	this.goodsdata=this.$route.params.goodsdata;
    	 	this.goodsdata.imgsrc=["/dist/1.svg","/dist/2.svg","/dist/3.svg"];
    	 	this.styledata.typedata = [{type:"89款",id:89},{type:"88款",id:88}];
    	 	this.styledata.colordata =[{type:"黑色",id:8812},{type:"白色",id:1588}];
    	 	this.infdata = {"name":"Joyoung／久阳","num":8812,type:"底盘加热","img":"/dist/3.svg"};
    	 	this.evaluatelist=[
    	 		{
    	 			"img":"/dist/3.svg",
    	 			"name":"陈****",
    	 			"score":5,
    	 			"type":"89款",
    	 			"color":"白色",
    	 			"content":"箱子很不错，很结实",
    	 			"time":"2017-12-21 12:02",
    	 		},
    	 		{
    	 			"img":"/dist/3.svg",
    	 			"name":"陈****",
    	 			"score":4,
    	 			"type":"89款",
    	 			"color":"白色",
    	 			"content":"箱子很不错，很结实",
    	 			"time":"2017-12-21 12:02",
    	 		},
    	 	];
    	 },
    	mounted(){
            document.title = "商品详情"
        },
        methods: {
        	changeimg(index){
        		this.imgtype=index;
            },
            setstyle(id,type,index){
            	if(index == 1){
            		this.type1 = id;
            		this.goodsdata.type = type;
            	}
            	if(index == 2){
            		this.type2 = id;
            		this.goodsdata.color = type;
            	}
            },
            changemenu(type){
            	this.menutype = type;
            },
            Gotobuy(){
            	this.goodsdata.num = this.num;
            	var userId = this.$route.params.userId;
            	var goodsdata = this.goodsdata;
            	this.$router.push({ name:'Payment', params: { goodsdata: goodsdata,userId:userId }})
            },
        }
    }
</script>