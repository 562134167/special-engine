<template>
    <div id="app">
        <div class="header"><tabs :tabs="page_data"></tabs></div>
        <div class="content">
            <router-view></router-view>
        </div>
        <footers></footers>
    </div>
</template>

<script type="text/ecmascript-6">
    import Tabs from "./components/tabs.vue"
    import Footers from "./components/footer.vue"
    import "./assets/less/site.less"
    export default {
    	data () {
            return {
                page_data: undefined,
            }
        },
        created() {

            this.page_data = {
            	"userId":2,   //用户ID
            	"name":"张三",   //用户名
            	"img_src":"/dist/logo.png",  //头像地址
            }
            
//           	this.$http.get('/user', {
//					params: {
//					ID: 12345
//					}
//				})
//				.then(function (response) {
//					this.page_data = response;
//				})
//				.catch(function (error) {
//					console.log(error);
//				});


        },
        components: {Tabs,Footers}
    }
    
</script>

