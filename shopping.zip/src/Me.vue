<template>
    <div>我</div>
</template>
<style></style>
<script type="text/ecmascript-6">
    export default{}
</script>