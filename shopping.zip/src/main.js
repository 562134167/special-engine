import Vue from 'vue'
import VueRouter from 'vue-router'
import VueResource from 'vue-resource'
import App from './App.vue'



//import Home from './components/home.vue'
import Category from './Category.vue'
import ShoppingCart from './Cart.vue'
import Me from './Me.vue'
import Gooddetail from "./goods/Gooddetail.vue"
import MyOrder from "./Order/MyOrder.vue"
import Evaluate from "./components/evaluate.vue"
import Payment from "./goods/Payment.vue"
import Payment_success from "./components/Payment_success.vue"


const Home = resolve => require(['./Home.vue'], resolve)

Vue.use(VueRouter)
Vue.use(VueResource)

const router = new VueRouter({
    //mode: 'history',
    base: __dirname,
    linkActiveClass: "active",
    routes: [
        {name:'Home', path: '/', component: Home},
        {name:'Categories',path: '/categories', component: Category},
        {name:'Me',path: '/me', component: Me},
        {name:'Gooddetail',path: '/goods/Gooddetail.vue', component: Gooddetail},
        {name:'MyOrder',path: '/Order/MyOrder', component: MyOrder},
        {name:'Evaluate',path: '/components/evaluate', component: Evaluate},
        {name:'Payment_success',path: '/components/Payment_success', component: Payment_success},
        {name:'Payment',path: '/goods/Payment', component: Payment},
    ]
})

new Vue({
    el: '#app',
    router,
    render: h => h(App)
})

